data:extend(
{
type = "recipe-category",
name = "pp-refining"
})
