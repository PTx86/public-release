require("utilValidate")

data:extend(
{
  {
    type = "technology",
    name = "ore-crushing",
    icon = "__pp-wishalloy-and-refining__/graphics/technology/wishalloy-sorting.png",
    icon_size = 128,
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "centrifugal-crusher"
      }
    },
    prerequisites = {"steel-processing"},
    unit =
    {
      count = 30,
      ingredients = {{"automation-science-pack", 1}},
      time = 15
    },
    order = "o"
  }
})
