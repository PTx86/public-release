
data:extend(
{
  {
    type = "item-group",
    name = "Phantasma-Praetori",
    icon = "__pp-wishalloy-and-refining__/graphics/icons/ore_washing.png",
    icon_size = 128,
    order = "t"
  },
  {
    type = "item-subgroup",
    name = "Tech",
    group = "Phantasma-Praetori",
    order = "u"
  },
  -- New Items Category


  -- new Building entity Category
  -- new Recipe category
  {
    type = "recipe-category",
    name = "pp-refining"
  }
})
