function pppipecovers()
  return {
    north =
    {
          filename = "__pp-wishalloy-and-refining__/graphics/pp-pipe/pp-pipe-cover-north.png",
          priority = "extra-high",
          width = 128,
          height = 128,
		  scale = 0.5,
    },
    east =
    {
          filename = "__pp-wishalloy-and-refining__/graphics/pp-pipe/clear.png",
          priority = "extra-high",
          width = 32,
          height = 32,
    },
    south =
    {
          filename = "__pp-wishalloy-and-refining__/graphics/pp-pipe/pp-pipe-cover-south.png",
          priority = "extra-high",
          width = 128,
          height = 128,
		  scale = 0.5,
    },
    west =
    {
          filename = "__pp-wishalloy-and-refining__/graphics/pp-pipe/clear.png",
          priority = "extra-high",
          width = 32,
          height = 32,
    }
  }
end
