local resource_autoplace = require('resource-autoplace');
local noise = require('noise');

--required base

data:extend(
{
    {
        type = "autoplace-control",
        name = "pp-wishalloy-ore",
        localised_name = {"", "[entity=pp-wishalloy-ore] ", {"entity-name.pp-wishalloy-ore"}},
        category = "resource",
        order = "b-e"
    },
    {
        type = "noise-layer",
        name = "pp-wishalloy-ore",
    },
    {
        type = "resource",
        name = "pp-wishalloy-ore",
        icon = "__pp-wishalloy-and-refining__/graphics/icons/wishalloy-ore.png",
        icon_size = 64,
        icon_mipmaps = 4,
        flags = {"placeable-neutral"},
        order = "a-b-a",
        tree_removal_probability = 0.3,
        tree_removal_max_distance = 16,
        map_color = {r = 0.902, g = 0.631, b = 0.012},
--tree distance, map sprite color and images
        minable =
        {--attempts to set the mining fluid have failed so far but the rest works
            mining_time = 5,
            mining_particle = "stone-particle",
            hardness = 2,
            results =
            {
                {
                    type = "item",
                    name = "pp-wishalloy-ore",
                    fluid_amount = 10,
                    required_fluid = "water",
                    amount_min = 1,
                    amount_max = 3,
                    probability = 0.8
                }
            }
        },
        collision_box = {{-0.1, -0.1}, {0.1, 0.1}},
        selection_box = {{-0.5, -0.5}, {0.5, 0.5}},
        --default generation set to sparse, dense and even generation
        autoplace = resource_autoplace.resource_autoplace_settings
        {
            name = "pp-wishalloy-ore",
            order = "p-p",
            base_density = 2,
            base_spots_per_km2 = 1,
            has_starting_area_placement = false,
            regular_rq_factor_multiplier = 0.9,
            starting_rq_factor_multiplier = 1.5,
        },
        stage_counts = {15000, 9500, 5500, 2900, 1300, 400, 150, 80},
        stages =
        {
            sheet =
            {
                filename = "__pp-wishalloy-and-refining__/graphics/entity/wishalloy/wishalloy-ore.png",
                priority = "extra-high",
                size = 64,
                frame_count = 8,
                variation_count = 8,
                hr_version =
                {
                    filename = "__pp-wishalloy-and-refining__/graphics/entity/wishalloy/hr-wishalloy-ore.png",
                    priority = "extra-high",
                    size = 128,
                    frame_count = 8,
                    variation_count = 8,
                    scale = 0.5
                }
            }
        }
    },
    {
        type = "item",
        name = "pp-wishalloy-ore",
        icon_size = 64,
        icon_mipmaps = 4,
        icon = "__pp-wishalloy-and-refining__/graphics/icons/wishalloy-ore.png",
        pictures = {
            {
                filename = "__pp-wishalloy-and-refining__/graphics/icons/wishalloy-ore.png",
                size = 64,
                scale = 0.25,
                mipmap_count = 4,
            },
            {
                filename = "__pp-wishalloy-and-refining__/graphics/icons/wishalloy-ore-1.png",
                size = 64,
                scale = 0.25,
                mipmap_count = 4,
            },
            {
                filename = "__pp-wishalloy-and-refining__/graphics/icons/wishalloy-ore-2.png",
                size = 64,
                scale = 0.25,
                mipmap_count = 4
            }
        },
        stack_size = 20,
    },


})
