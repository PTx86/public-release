function pppipepictures()
  return
  {
    north =
    {
      filename = "__pp-wishalloy-and-refining__/graphics/entity/centrifugal-crusher-pipe-n.png",
      priority = "extra-high",
      width = 256,
      height = 256,
      shift = {0.28125, 2},
	  scale = 0.5
    },
    east =
    {
      filename = "__pp-wishalloy-and-refining__/graphics/entity/centrifugal-crusher-pipe-e.png",
      priority = "extra-high",
      width = 256,
      height = 256,
      shift = {-1.71875, 0},
	  scale = 0.5
    },
    south =
    {
      filename = "__pp-wishalloy-and-refining__/graphics/entity/centrifugal-crusher-pipe-s.png",
      priority = "extra-high",
      width = 256,
      height = 256,
      shift = {0.28125, -2},
	  scale = 0.5
    },
    west =
    {
      filename = "__pp-wishalloy-and-refining__/graphics/entity/centrifugal-crusher-pipe-w.png",
      priority = "extra-high",
      width = 256,
      height = 256,
      shift = {2.28125, 0},
	  scale = 0.5
    }
  }
end
