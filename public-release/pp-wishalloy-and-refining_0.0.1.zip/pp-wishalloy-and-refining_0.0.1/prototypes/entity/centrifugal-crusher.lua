require("prototypes/pp-pipe-pictures")
require("prototypes/pp-pipe-covers")

data:extend(
{
  {
    type = "item",
    name = "centrifugal-crusher",
    icon = "__pp-wishalloy-and-refining__/graphics/icons/centrifugal-crusher.png",
    icon_size = 64,
    subgroup = "production-machine",
    order = "p-p-c",
    place_result = "centrifugal-crusher",
    stack_size = 10
  },
  {
    type = "recipe",
    name = "centrifugal-crusher",
    energy_required = 7.0,
    enabled = true,
    ingredients =
    {
      {"iron-plate", 6},
      {"pp-wishalloy-ore", 20},
      {"iron-gear-wheel", 4},
      {"copper-cable", 10},
      {"stone-brick", 20}
    },
    result = "centrifugal-crusher"
  },
  {
    type = "technology",
    name = "ore-crushing"
  },
  {
    type = "assembling-machine",
    name = "centrifugal-crusher",
    icon = "__pp-wishalloy-and-refining__/graphics/icons/centrifugal-crusher.png",
    icon_size = 64,
    flags = {"placeable-neutral", "placeable-player", "player-creation"},
    minable = {hardness = 0.2, mining_time = 0.5, result = "centrifugal-crusher"},
    max_health = 300,
    corpse = "big-remnants",
    fluid_boxes =
    {
      {
        production_type = "input",
        pipe_picture = pppipepictures(),
        pipe_covers = pppipecovers(),
        base_area = 10,
        base_level = -1,
        pipe_connections = {{ type = "input", position = {0, -2} }},
        secondary_draw_orders = { north = -1 }
      },
      {
        production_type = "output",
        pipe_covers = pppipecovers(),
        base_area = 10,
        base_level = 1,
        pipe_connections = {{ type = "output", position = {0, 2} }}
      },
      off_when_no_fluid_recipe = true
    },
    collision_box = {{-1.2, -1.2}, {1.2, 1.2}},
    selection_box = {{-1.5, -1.5}, {1.5, 1.5}},
    crafting_categories = {"crafting", "pp-refining"},
    energy_usage = "550kW",
    ingredient_count = 4,
    crafting_speed = 1,
    energy_source =
    {
      type = "electric",
      input_priority = "secondary",
      usage_priority = "secondary-input",
      emissions_per_minute = 0.1,
    },
    fast_replaceable_group = "assembling-machine",
    module_specification =
    {
      module_slots = 1
    },
    allowed_effects = {"consumption", "speed", "productivity", "pollution"},
    working_sound =
    {
      sound = {
        {
          filename = "__base__/sound/centrifuge-6.ogg",
          volume = 0.5
        },
      },
      idle_sound = { filename = "__base__/sound/idle1.ogg", volume = 0.2 },
      apparent_volume = 1.1,
    },
    animation =
    {
      south = { filename = "__pp-wishalloy-and-refining__/graphics/entity/pp-centrifugal-crusher-v.png", width = 256, height = 256, shift = {0.3125, 0.125}, scale = 0.5, frame_count = 14, line_length = 7, animation_speed = 1.0 },
      west = { filename = "__pp-wishalloy-and-refining__/graphics/entity/pp-centrifugal-crusher-h.png", width = 256, height = 256, shift = {0.3125, 0}, scale = 0.5, frame_count = 14, line_length = 7, animation_speed = 1.0 },
      north = { filename = "__pp-wishalloy-and-refining__/graphics/entity/pp-centrifugal-crusher-v.png", width = 256, height = 256, shift = {0.3125, 0.125}, scale = 0.5, frame_count = 14, line_length = 7, animation_speed = 1.0 },
      east = { filename = "__pp-wishalloy-and-refining__/graphics/entity/pp-centrifugal-crusher-h.png", width = 256, height = 256, shift = {0.3125, 0}, scale = 0.5, frame_count = 14, line_length = 7, animation_speed = 1.0 },
    },
  }
})
