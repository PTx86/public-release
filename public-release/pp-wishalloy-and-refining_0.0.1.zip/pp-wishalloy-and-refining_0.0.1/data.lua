-- phantasma praeteri is a mouthful to say, but PP is funni
-- wishalloy-and-refining is the name of this splinter
require("prototypes/resources/pp-wishalloy-ore")
require("prototypes/entity/centrifugal-crusher")
require("prototypes/technology.lua")
require("prototypes/categories/categories.lua")
